import CompoundInterestCalculator from './CompoundInterestCalculator';

function App() {
  return <CompoundInterestCalculator />;
}

export default App;
